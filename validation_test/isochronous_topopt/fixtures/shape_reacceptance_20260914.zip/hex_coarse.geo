// Auto-generated Radia GMSH launch companion for hex_coarse.msh
// Open this .geo for normal review; open .msh only for raw data inspection.
Merge "hex_coarse.msh";

General.Orthographic = 1;
General.Trackball = 0;
General.RotationX = -68;
General.RotationY = 0;
General.RotationZ = 0;
General.RotationCenterGravity = 1;
Mesh.NumSubEdges = 4;
Mesh.SurfaceFaces = 1;
Mesh.SurfaceEdges = 1;
Mesh.VolumeEdges = 0;
Mesh.VolumeFaces = 0;
Mesh.ColorCarousel = 2;
